// script.js

// Define the questions and their correct answers
const questions = [
    { id: 'question1', answer: 'Sometimes' },
    // Add more questions and answers here
];

document.addEventListener('DOMContentLoaded', () => {
    const submitButton = document.getElementById('submit-button');

    submitButton.addEventListener('click', () => {
        const userAnswers = {};

        // Get the selected answer for each question
        questions.forEach((question) => {
            const selectedAnswer = document.querySelector(`input[name=${question.id}]:checked`);
            if (selectedAnswer) {
                userAnswers[question.id] = selectedAnswer.value;
            }
        });

        // Calculate the user's score based on their answers
        const score = calculateMentalHealthScore(userAnswers);

        // Display the score and a suggestion
        showResult(score);
    });
});

function calculateMentalHealthScore(userAnswers) {
    let score = 0;

    // Calculate the score based on user answers
    questions.forEach((question) => {
        if (userAnswers[question.id] === question.answer) {
            // You can define scoring logic here, e.g., adding points for each correct answer
            score += 1;
        }
    });

    return score;
}

function showResult(score) {
    const resultContainer = document.createElement('div');
    resultContainer.classList.add('result-container');
    resultContainer.innerHTML = `
        <h2>Your Mental Health Score: ${score}</h2>
        <p>Your personalized suggestion here.</p>
    `;

    // Append the result to the quiz container
    const quizContainer = document.querySelector('.quiz-container');
    quizContainer.appendChild(resultContainer);
}
